# Partner Within 升级补丁

## 先说明
不要删除整个仓库。保留现有 `css/style.css`、`js/app.js`、`js/events.js`，因为本补丁依赖原有手机界面。

## 网站文件部署
1. 覆盖根目录 `index.html`（如果你不想覆盖，可只在原 index.html 的 `</body>` 前加入 `<script src="js/persona-engine.js"></script>`，并添加 AI 设置区；本包的 index.html 版本已包含这些内容）。
2. 覆盖 `js/data.js`。
3. 新增 `js/persona-engine.js`。
4. 保留 `css/style.css`、`js/app.js`、`js/events.js`。
5. 提交到 GitHub，等待 Pages 部署。

## 旧数据提醒
浏览器 localStorage 会保留之前的角色数据，因此覆盖 `data.js` 不会自动改变旧联系人。先在配置中心导出 JSON 备份。如需载入新默认角色，可在网站浏览器 Console 执行：
`localStorage.removeItem("phoneSimData"); location.reload();`
这会清除本网站保存的联系人和聊天记录。不要在没备份时执行。

## 本地角色模式
配置中心 → AI 角色引擎，关闭“启用真实 AI 回复”。这会使用规则式本地回复，便于测试角色语气差异；它不是完整 AI 模型。

## 真正的 AI 对话
1. 在 Cloudflare Workers 创建 Worker，将 `worker/index.js` 内容粘贴进去并部署。
2. 在 Worker 设置里添加 Secret：`AI_API_KEY`（模型服务商的密钥）。不要把密钥放进 GitHub 文件。
3. 可选设置 `AI_BASE_URL`（默认 `https://api.openai.com/v1`）和 `AI_MODEL`（默认 `gpt-4o-mini`）。使用你能访问、已开通且计费可接受的兼容服务。
4. 复制 Worker 地址并加 `/chat`，例如 `https://xxx.workers.dev/chat`。
5. 在网站配置中心启用 AI，填写后端地址，点“测试 AI 连接”，再点“完成并应用”。

本地模式没有模型费用，但回复能力有限；真实 AI 需模型服务 API，调用仍受服务商价格、速率和上下文窗口限制。网页端没有固定聊天次数上限。
